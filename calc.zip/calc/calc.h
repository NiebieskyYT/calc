#include <cmath>
int Num_A = 0;
int Num_B = 0;
long long int Sum = 0;
char Operation;
void Addition() {
  Sum = Num_A + Num_B;
}
void Subtraction() {
  Sum = Num_A - Num_B;
}
void Multiplication() {
  Sum = Num_A * Num_B;
}
void Division() {
  Sum = Num_A / Num_B;
}
void PowerOf() {
  Sum = pow(Num_A, Num_B);
}

