#include "calc.h"
#include <iostream>
using namespace std;
int main() {
  cout << "Please Enter Number A: ";
  cin >> Num_A;
  cout << "Please Enter Number B: ";
  cin >> Num_B;
  cout << "Please Enter Operator (+/-/x/÷/^): ";
  cin >> Operation;
  if (Operation == '+') {
    Addition();
  } else if (Operation == '-') {
    Subtraction();
  } else if (Operation == '*') {
    Multiplication();
  } else if (Operation == '/') {
    Division();
  } else if (Operation == '^') {
    PowerOf();
  } else {
    cout << "Invalid operation. Please try again.";
  }
  cout << Sum << "\n";
}
